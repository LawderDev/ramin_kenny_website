export const IS_ACTIVE = 'isActive';
export const IS_DONE = 'isDone';
export const IS_NOT_DONE = 'isNotDone';
