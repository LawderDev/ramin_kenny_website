export const EXCLUDED_SORT_OPTIONS = [
  'media',
  'richtext',
  'dynamiczone',
  'relation',
  'component',
  'json',
];
